package dao;

public interface IDao<E> {

    E salvar(E t);

}
