import model.Endereco;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class Main {

    public static void main(String[] args) {

    }

}
